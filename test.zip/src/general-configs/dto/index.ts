export * from './create-general-config.dto';
export * from './update-general-config.dto';
export * from './list-general-configs.dto';
export * from './set-typed-value.dto';
