-- AlterTable
ALTER TABLE "public"."batches" ADD COLUMN     "lowStockThreshold" INTEGER NOT NULL DEFAULT 10;
