-- AlterTable
ALTER TABLE "public"."users" ADD COLUMN     "phoneNumber" TEXT;
